package id.web.estherirawati.resto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
