import 'dart:convert';

import 'package:flutter/material.dart';

import 'detailrestaurant.dart';
import 'model/restaurant.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Restaurants App',
        theme: ThemeData(
            primarySwatch: Colors.blue,
            visualDensity: VisualDensity.adaptivePlatformDensity),
        initialRoute: RestaurantListScreen.routeName,
        routes: {
          RestaurantListScreen.routeName: (context) =>
              const RestaurantListScreen(),
          DetailRestaurantScreen.routeName: (context) => DetailRestaurantScreen(
              resto: ModalRoute.of(context)?.settings.arguments as Restaurants),
        });
  }
}

class RestaurantListScreen extends StatelessWidget {
  static const routeName = 'news_list';

  const RestaurantListScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Restaurant App"),
      ),
      body: FutureBuilder<String>(
        future: DefaultAssetBundle.of(context)
            .loadString('assets/local_restaurant.json'),
        builder: (context, snapshot) {
          final List<Restaurants> restaurants = parseRestaurants(snapshot.data);
          return ListView.builder(
              itemCount: restaurants.length,
              itemBuilder: (context, index) {
                return _buildRestaurantItem(context, restaurants[index]);
              });
        },
      ),
    );
  }
}

List<Restaurants> parseRestaurants(String? json) {
  if (json == null) {
    return [];
  }
  final List parsed = jsonDecode(json)["restaurants"];
  return parsed.map((json) => Restaurants.fromJson(json)).toList();
}

Widget _buildRestaurantItem(BuildContext context, Restaurants resto) {
  return Material(
      child: ListTile(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
          leading: Image.network(resto.pictureId, width: 100),
          title: Text(resto.name,
              style: const TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                  fontSize: 16)),
          subtitle: Column(
            children: [
              Row(
                children: [
                  Icon(Icons.add_location),
                  Text(resto.city),
                ],
              ),
              Row(
                children: [
                  Icon(Icons.star),
                  Text(resto.rating.toString()),
                ],
              ),
            ],
          ),
          onTap: () {
            Navigator.pushNamed(context, DetailRestaurantScreen.routeName,
                arguments: resto);
          }));
}
